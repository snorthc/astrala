// The extension's only job: pass a website's request to the Astrala app on this computer and pass the answer back.
// The app listens on 127.0.0.1 only, and only answers the extension it was paired with (a token kept here).
// Every request is a POST: Chrome leaves an extension's Origin header off GET requests, and the app checks it.
// The browser wallet's own engine (src/web, bundled to engine.js): used when there is no Astrala app on this computer.
try { importScripts('engine.js') } catch (e) { console.error('Astrala: the browser wallet engine did not load', e) }
const localMode = async () => (await chrome.storage.local.get('mode')).mode === 'local'
const PORTS = [47821, 47822, 47823]
let port = null

async function talk(p, path, { body, token } = {}) {
  const r = await fetch(`http://127.0.0.1:${p}${path}`, {
    method: body ? 'POST' : 'GET',
    headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined
  })
  return { status: r.status, json: await r.json().catch(() => ({})) }
}
/** Find the app (it takes the first free port of three), then ask. null: the app isn't there. */
async function app(path, opts = {}) {
  for (const p of port ? [port, ...PORTS.filter((x) => x !== port)] : PORTS) {
    try {
      if (p !== port) { const hi = await talk(p, '/hello', { body: {} }); if (hi.json.astrala !== 1) continue } // something else may own this port
      const r = await talk(p, path, opts)
      port = p
      return r
    } catch { /* nothing listening on this one */ }
  }
  port = null
  return null
}
const token = async () => (await chrome.storage.local.get('token')).token || null
const siteOf = (sender) => { try { const o = sender.origin || new URL(sender.url).origin; return /^https?:\/\//.test(o) ? o : null } catch { return null } }
const NOT_OPEN = "Astrala isn't reachable. Open the app and turn on Settings → Security → Browser extension."

async function rpc(origin, method, params) {
  if (!origin) return { error: { code: 4100, message: "Astrala can't be used on this kind of page" } }
  if (await localMode()) return { error: { code: 4100, message: "Connecting to websites isn't in the browser wallet yet. The Astrala app has it." } }
  const t = await token()
  if (!t) return { error: { code: 4100, message: 'Pair the Astrala extension with the app first: click the Astrala icon in your browser.' } }
  const r = await app('/rpc', { token: t, body: { origin, method, params } })
  if (!r) return { error: { code: 4900, message: NOT_OPEN } }
  if (r.status === 401) { await chrome.storage.local.remove('token'); return { error: { code: 4100, message: 'This extension is no longer paired with Astrala. Click the Astrala icon to pair again.' } } }
  if (r.status !== 200) return { error: { code: -32603, message: 'Astrala refused that request' } }
  return r.json
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || sender.id !== chrome.runtime.id) return
  // from a page, through content.js: the site's origin comes from the browser, never from the page
  if (msg.type === 'rpc') { rpc(siteOf(sender), String(msg.method), msg.params).then(reply); return true }
  // from a page's content script, once per page: is this site dressed up as a well-known one? Marks the toolbar icon too.
  if (msg.type === 'check') { (async () => {
    if (await localMode()) return reply(null) // the browser wallet never tells anything on this computer which sites you open
    const origin = siteOf(sender), t = await token()
    const r = origin && t ? await app('/site', { token: t, body: { origin } }) : null
    const hit = r && r.status === 200 && r.json.imitates ? r.json : null
    if (hit && sender.tab) { chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color: '#c93b3b' }); chrome.action.setBadgeText({ tabId: sender.tab.id, text: '!' }) }
    reply(hit)
  })(); return true }
  // from the extension's own pages (the toolbar window, or one opened in a tab), never from a website's content script
  if (!String(sender.url || '').startsWith(chrome.runtime.getURL(''))) return
  if (msg.type === 'status') { (async () => { const r = await app('/hello', { token: await token(), body: {} }); reply(r ? { running: true, ...r.json } : { running: false }) })(); return true }
  if (msg.type === 'pair') { (async () => {
    const r = await app('/pair', { body: { code: msg.code } })
    if (r && r.status === 200 && r.json.token) { await chrome.storage.local.set({ token: r.json.token }); reply({ ok: true }) }
    else reply({ ok: false, why: !r ? NOT_OPEN : r.status === 423 ? 'Astrala is locked. Unlock it, then pair.' : r.status === 429 ? 'Astrala is busy with another question. Try again in a moment.' : 'Pairing was declined in Astrala.' })
  })(); return true }
  if (msg.type === 'site') { rpc(msg.origin, msg.method, []).then(reply); return true }
})

// ---------------------------------------------------------------- Anonymous install heartbeat + live config poller.
// HQ_URL is baked in at build time from ops/hq-url.ts (if present); in the public build the
// constant below is empty and this whole section no-ops. The only three fields that reach HQ
// are a random install id, the extension version, and a platform label — no addresses, no
// transactions, no IP tracking. Opt-in: off by default; the user turns it on from the
// extension's Settings screen, which stores the flag in chrome.storage.local.
// https on a public host only; plain http or a loopback address counts as "no HQ" (same rule as the app)
const HQ_URL = (() => {
  const s = String(globalThis.ASTRALA_HQ_URL || '').trim().replace(/\/+$/, '')
  try {
    const u = new URL(s), h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '')
    if (u.protocol !== 'https:' || u.username || u.password) return ''
    if (h === 'localhost' || h.endsWith('.localhost') || h === '::1' || /^127\./.test(h) || h === '0.0.0.0') return ''
    return s
  } catch { return '' }
})()
const platformLabel = async () => {
  try { const i = await chrome.runtime.getPlatformInfo(); const b = (await chrome.management.getSelf?.())?.installType; if (b) {} } catch {}
  const ua = (globalThis.navigator?.userAgent || '')
  if (/Edg\//.test(ua)) return 'edge'
  if (/OPR\//.test(ua)) return 'chrome'
  if (/Firefox\//.test(ua)) return 'firefox'
  if (/Brave/.test(ua)) return 'brave'
  return 'chrome'
}
async function heartbeat() {
  if (!HQ_URL) return
  const { heartbeat: on, heartbeatId: savedId } = await chrome.storage.local.get(['heartbeat', 'heartbeatId'])
  if (!on) return
  let id = savedId
  if (!/^[a-f0-9]{16,64}$/i.test(id || '')) {
    const buf = new Uint8Array(16); crypto.getRandomValues(buf)
    id = [...buf].map((b) => b.toString(16).padStart(2, '0')).join('')
    await chrome.storage.local.set({ heartbeatId: id })
  }
  try {
    await fetch(`${HQ_URL}/api/i`, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, v: chrome.runtime.getManifest().version, p: await platformLabel() }) })
  } catch { /* offline, HQ down — fine */ }
}
async function pollLive() {
  if (!HQ_URL) return
  try {
    const r = await fetch(`${HQ_URL}/api/live.json`)
    if (!r.ok) return
    const live = await r.json()
    await chrome.storage.local.set({ live, liveAt: Date.now() })
  } catch {}
}
chrome.runtime.onInstalled?.addListener(() => { heartbeat(); pollLive(); chrome.alarms?.create('hq', { periodInMinutes: 360 }) })
chrome.alarms?.onAlarm.addListener((a) => { if (a.name === 'hq') { heartbeat(); pollLive() } })

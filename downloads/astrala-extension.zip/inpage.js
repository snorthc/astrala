// Runs in the page. The standard wallet object websites look for (EIP-1193), announced the modern way (EIP-6963).
// It knows nothing and holds nothing: every request goes to the Astrala app, which answers or refuses.
(() => {
  if (window.astrala) return
  const waiting = new Map(), listeners = {}
  let seq = 0, state = { accounts: [], chainId: '0x1' }, connected = false
  const emit = (ev, v) => (listeners[ev] || []).slice().forEach((f) => { try { f(v) } catch (e) { console.error(e) } })
  // the app sends the site's current account and network with every answer; tell the page when either changed
  const apply = (s) => {
    if (!s || !Array.isArray(s.accounts)) return
    const acc = JSON.stringify(s.accounts) !== JSON.stringify(state.accounts), chain = s.chainId !== state.chainId
    state = { accounts: s.accounts, chainId: s.chainId }
    if (!connected) { connected = true; emit('connect', { chainId: state.chainId }) }
    if (chain) emit('chainChanged', state.chainId)
    if (acc) emit('accountsChanged', state.accounts)
  }
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.to !== 'astrala-inpage') return
    const w = waiting.get(e.data.id)
    if (!w) return
    waiting.delete(e.data.id)
    apply(e.data.state)
    if (e.data.error) w.fail(Object.assign(new Error(e.data.error.message || 'Astrala refused that'), { code: e.data.error.code }))
    else w.ok(e.data.result)
  })
  const request = (args) => new Promise((ok, fail) => {
    if (!args || typeof args.method !== 'string') return fail(Object.assign(new Error('Invalid request'), { code: -32600 }))
    const id = `${Date.now()}-${++seq}`
    waiting.set(id, { ok, fail })
    window.postMessage({ to: 'astrala-content', id, method: args.method, params: args.params == null ? [] : args.params }, '*')
  })
  const provider = {
    isAstrala: true,
    request,
    on(ev, f) { (listeners[ev] = listeners[ev] || []).push(f); return provider },
    removeListener(ev, f) { listeners[ev] = (listeners[ev] || []).filter((x) => x !== f); return provider },
    // older sites
    enable: () => request({ method: 'eth_requestAccounts' }),
    send: (m, p) => (typeof m === 'string' ? request({ method: m, params: p }) : request(m)),
    sendAsync: (payload, cb) => request(payload).then((result) => cb(null, { id: payload.id, jsonrpc: '2.0', result }), (err) => cb(err))
  }
  provider.addListener = provider.on
  provider.off = provider.removeListener
  Object.defineProperty(provider, 'chainId', { get: () => state.chainId })
  Object.defineProperty(provider, 'selectedAddress', { get: () => state.accounts[0] || null })

  const icon = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#08080b"/><circle cx="32" cy="32" r="13" fill="none" stroke="#f1dfc2" stroke-width="3"/><circle cx="32" cy="33" r="10.5" fill="#060608"/><path d="M5 39C20 33 44 27 59 26C44 32 20 38 5 39Z" fill="#f4e3c4"/></svg>')
  const detail = Object.freeze({ info: Object.freeze({ uuid: crypto.randomUUID(), name: 'Astrala', icon, rdns: 'app.astrala.wallet' }), provider })
  const announce = () => window.dispatchEvent(new CustomEvent('eip6963:announceProvider', { detail }))
  window.addEventListener('eip6963:requestProvider', announce)
  announce()

  window.astrala = provider
  if (!window.ethereum) window.ethereum = provider // never push another wallet aside; sites that list wallets find Astrala by its announcement
})()

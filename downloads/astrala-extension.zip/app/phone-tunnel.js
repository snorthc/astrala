// The iPhone web app's link to Astrala on your Mac (served by main/phone.ts, same origin, HTTPS).
// Gives the wallet's screens `window.astrala`, the object the desktop window gets from its preload: every call goes
// to the Mac with this phone's pairing token. Keys never come here. Unpaired, it shows how to pair instead.
(() => {
  const KEY = 'astrala-phone-token'
  window.__astralaExt = 'phone'
  window.__astralaPhone = true
  let tok = localStorage.getItem(KEY), leaving = false
  const post = async (path, body) => {
    const r = await fetch(path, { method: 'POST', headers: { 'content-type': 'application/json', ...(tok ? { authorization: `Bearer ${tok}` } : {}) }, body: JSON.stringify(body) })
    return { status: r.status, json: await r.json().catch(() => ({})) }
  }

  // ---- not paired: a small page of its own, then a reload into the wallet
  const el = (tag, css, text) => { const e = document.createElement(tag); if (css) e.style.cssText = css; if (text) e.textContent = text; return e }
  function gate(why) {
    if (leaving) return new Promise(() => {})
    leaving = true
    const show = () => {
      document.body.replaceChildren()
      const box = el('div', 'position:fixed;inset:0;display:grid;place-items:center;padding:28px calc(24px + env(safe-area-inset-right)) 28px calc(24px + env(safe-area-inset-left));background:radial-gradient(90% 60% at 50% 0%,#2a1d12,#050507 70%);color:#f1e6d6;font:15px/1.5 -apple-system,system-ui,sans-serif;text-align:center')
      const card = el('div', 'max-width:360px;width:100%')
      const img = el('img', 'width:72px;height:72px;border-radius:18px;margin:0 auto 18px;display:block;box-shadow:0 12px 40px rgba(227,163,92,.25)'); img.src = '/apple-touch-icon.png'; img.alt = ''
      const h = el('h1', 'font-size:24px;font-weight:650;letter-spacing:-.02em;margin:0 0 8px', 'Astrala on your iPhone')
      const p = el('p', 'margin:0 0 22px;color:#b9ad9e', why || 'Pair this phone with the Astrala app on your Mac. Your keys stay on the Mac; the phone only shows the wallet and asks it to act.')
      const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, '0')
      const big = el('div', 'font:600 34px/1 ui-monospace,Menlo,monospace;letter-spacing:.12em;margin:0 0 10px;display:none', `${code.slice(0, 3)} ${code.slice(3)}`)
      const btn = el('button', 'width:100%;height:52px;border:0;border-radius:26px;background:#efe6d8;color:#15130f;font:600 16px -apple-system,system-ui;cursor:pointer', 'Pair with my Mac')
      const note = el('p', 'margin:18px 0 0;font-size:13px;color:#8d8275', 'On the Mac: Astrala must be open and unlocked, with Settings → Security → iPhone turned on.')
      btn.onclick = async () => {
        btn.disabled = true; btn.textContent = 'Approve it on your Mac…'; big.style.display = 'block'
        p.textContent = 'Your Mac is showing this code. Approve it there only if it matches.'
        const r = await post('/pair', { code }).catch(() => null)
        if (r && r.status === 200 && r.json.token) { localStorage.setItem(KEY, r.json.token); location.replace('/?phone'); return }
        btn.disabled = false; btn.textContent = 'Try again'; big.style.display = 'none'
        p.textContent = !r ? "Can't reach your Mac. Check you're on the same Wi-Fi (or Tailscale) and the iPhone switch is on." : r.status === 423 ? 'Unlock Astrala on your Mac first, then try again.' : r.status === 429 ? 'Another pairing request is waiting on the Mac. Answer or decline it first.' : 'Pairing was declined on the Mac.'
      }
      card.append(img, h, p, big, btn, note); box.append(card); document.body.append(box)
    }
    if (document.body) show(); else addEventListener('DOMContentLoaded', show)
    return new Promise(() => {})
  }
  if (!tok) gate()

  const IN_APP = { ok: false, error: 'For your safety this is only done in the Astrala app on your Mac.' }
  const DENIED = { revealMnemonic: null, generateMnemonic: '', windowControl: { maximized: false }, discordPresence: 'off', traySummary: undefined, setBadge: undefined, notifyOs: undefined, pickBackup: null }
  const call = (name) => async (...args) => {
    const r = await post('/ipc', { name, args }).catch(() => null)
    if (!r) throw new Error("Can't reach Astrala on your Mac")
    if (r.status === 401) { localStorage.removeItem(KEY); tok = null; return gate('This phone was unpaired. Pair it again to keep using Astrala.') }
    if (r.json.denied) return name in DENIED ? DENIED[name] : IN_APP
    if (r.json.error) throw new Error(r.json.error)
    return r.json.result
  }

  const subs = {}
  let seq = -1, pumping = false
  async function pump() {
    if (pumping) return
    pumping = true
    for (;;) {
      const r = await post('/events', { after: seq }).catch(() => null)
      if (leaving) return
      if (!r || r.status !== 200 || !Array.isArray(r.json.events)) { await new Promise((ok) => setTimeout(ok, 2000)); continue }
      seq = r.json.seq
      for (const e of r.json.events) for (const cb of subs[e.channel] || []) { try { cb(...e.args) } catch (err) { console.error(err) } }
    }
  }
  const fixed = { platform: 'darwin',
    copy: (t) => navigator.clipboard.writeText(String(t)).catch(() => {}), paste: () => navigator.clipboard.readText().catch(() => '') }
  window.astrala = new Proxy(fixed, {
    get(t, k) {
      if (typeof k !== 'string' || k === 'then') return undefined
      if (k in t) return t[k]
      if (/^on[A-Z]/.test(k)) return (cb) => {
        const ch = k === 'onWindowState' ? 'winState' : k[2].toLowerCase() + k.slice(3)
        ;(subs[ch] = subs[ch] || new Set()).add(cb)
        pump()
        return () => subs[ch].delete(cb)
      }
      return (t[k] = call(k))
    }
  })
})()
